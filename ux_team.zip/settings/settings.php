<?php


/**    TODO: delete api/install.php file after installation   **/



$google_api_id = '39575750767-4d3ieqoemj7kc43hi76qrp9ft2qnqo3e.apps.googleusercontent.com';
$api_key = 'AIzaSyD5_k-oAl-WZNaDGey4k3U9_noryurZjKo';
$client_secret = 'H-4n_ZGNKJphWXdRW3OGTPrF';


$db_host = '127.0.0.1';
$db_user = 'root';
$db_pass = '';
$db_name = 'ux';


$admin_email = 'mybodya@gmail.com';


$error_reporting_level = E_ALL ^ E_DEPRECATED;

/***************************************************************
 **    TODO: for production set to ZERO!    **/
//    error_reporting(0);

error_reporting($error_reporting_level);
